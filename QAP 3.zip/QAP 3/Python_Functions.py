# Library of functions for formatting numbers and dates.

import datetime as datetime




def FDollar2(DollarValue):
    # Function will accept a value and format it to $#,###.##.

    DollarValueStr = "${:,.2f}".format(DollarValue)

    return DollarValueStr


def FDollar0(DollarValue):
    # Function will accept a value and format it to $#,###.

    DollarValueStr = "${:,.0f}".format(DollarValue)

    return DollarValueStr


def FComma2(Value):
    # Function will accept a value and format it to #,###.##.

    ValueStr = "{:,.2f}".format(Value)

    return ValueStr


def FComma0(Value):
    # Function will accept a value and format it to #,###.

    ValueStr = "{:,.0f}".format(Value)

    return ValueStr


def FNumber0(Value):
    # Function will accept a value and format it to ####.

    ValueStr = "{:.0f}".format(Value)

    return ValueStr


def FNumber1(Value):
    # Function will accept a value and format it to ####.#.

    ValueStr = "{:.1f}".format(Value)

    return ValueStr


def FNumber2(Value):
    # Function will accept a value and format it to ####.##.

    ValueStr = "{:.2f}".format(Value)

    return ValueStr


def FDateS(DateValue):
    # Function will accept a value and format it to yyyy-mm-dd.

    DateValueStr = DateValue.strftime("%Y-%m-%d")

    return DateValueStr


def FDateM(DateValue):
    # Function will accept a value and format it to dd-Mon-yy.

    DateValueStr = DateValue.strftime("%d-%b-%y")

    return DateValueStr


def FDateL(DateValue):
    # Function will accept a value and format it to Day, Month dd, yyyy.

    DateValueStr = DateValue.strftime("%A, %B %d, %Y")

    return DateValueStr

#added Functions

def UnixTimeCon(DateValue):

    unix_timestamp = DateValue.timestamp()

    return unix_timestamp



def PhoneNumFormat():
    #Function will allow the phone number to be proper format ###-###-####
        IncorrectFormat = True

        while IncorrectFormat is True:
                PhoneInput = input(f"Enter Customers phone number ###-###-####: ")

                if PhoneInput =="":
                    print()
                    print('    Data entery error - Phone Number cannot be blank.') 
                    print()

                cleaned_digits =''.join(filter(str.isdigit, PhoneInput))

                if len(cleaned_digits) != 10:
                    print("Invalid phone number. Please enter a 10-digit number.")
                    IncorrectFormat = True
                    
                else:

        # Formatting and Extraction 

                    area_num = cleaned_digits[0:3]
                    mid_num = cleaned_digits[3:6]
                    last_num = cleaned_digits[6:10]

                    Formatted_Number = f"({area_num}) {mid_num}-{last_num}"
                    

                    print(f"Formatted Phone Number: {Formatted_Number}")
                    IncorrectFormat = False
                    return Formatted_Number

def CarPlateNumber():
      # This function will allow you to have Correct Plate Numbers
      IncorrectFormat = True


      while IncorrectFormat is True:
            
            CarPlate = input(f"Enter the Vechiles Plate Number XXX###: ").upper()

            if CarPlate =="":
                print()
                print('    Data entery error - Plate Number cannot be blank.') 
                print()

            cleaned_letters = ''.join(filter(str.isalpha,  CarPlate[0:3]))
           
            cleaned_numbers = ''.join(filter(str.isdigit, CarPlate[3:6]))

            if len(cleaned_letters) == 3 and len(cleaned_numbers) == 3:
                PlateNum = CarPlate[3:6]
                PlateLetters = CarPlate[0:3].upper()

                FormattedPlateNum = f"{PlateLetters}{PlateNum}"

                print(f"Formatted Plate Number: {FormattedPlateNum}")
                IncorrectFormat = False   

            else:
                print(f" Data entery error - Cannot use number.")
                IncorrectFormat = True
                

            return FormattedPlateNum
      

    