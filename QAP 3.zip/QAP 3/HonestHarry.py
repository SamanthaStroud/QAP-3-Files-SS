# Honest Harry Used Car lot invoices
# Author: Samantha Stroud
# Date(s): July 18, 2025

# Define required libraries.
import datetime 
import re
import Python_Functions as PF
import sys

# Define program constants.
LICENSE_FEE_LOWER = 75.00   # up to $15,000
LICENSE_FEE_HIGHER = 165.00 # over $15,000
TRANSFER_FEE = 1         #1%
HIGH_TRANSFER_FEE = 1.6             #1.6% lux fee and the 1% reg fee
HST_FEE = 15              # 15%
FINANCING_FEE = 39.99       
LOAN_YEARS = 4


# Main program starts here.

d = datetime
r = re

while True:

    # gather user Inputs
        while True:
                    Allowed_Char = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz-'")
                  
                    while True:
                            CustFirstName = input(f"Enter Customers First name (END to quit): ").title()

                            if CustFirstName  == "":
                                print()
                                print('    Data entry error - Customer name cannot be blank.') 
                                print()
                            elif CustFirstName.upper() == "END":
                                  sys.exit()
                            elif set(CustFirstName).issubset(Allowed_Char) == False:
                                print()
                                print("     Data entry error - Customer Name contains invalid characters.")
                                print()
                            else:
                                break
                            
                            
                    while True:
                            CustLastName = input(f"Enter Customers last Name: ").title()

                            if CustLastName  == "":
                                print()
                                print('    Data entry error - Customer name cannot be blank.') 
                                print()
                            elif set(CustLastName).issubset(Allowed_Char) == False:
                                print()
                                print("     Data entry error - Customer Name contains invalid characters.")
                                print()
                            else:
                                break
                            
                    while True:
                            
                            CustPhoneNum = PF.PhoneNumFormat()
                            break 

                    
                    while True:

                       PlateNum = PF.CarPlateNumber()
                       break
                
                # Vehicle Information Input 
                    while True:
                        Allowed_Char_Num = set("1234567890")


                        VehicleYear = input("Enter the Vehicle Year (2002): ").title()
                        if VehicleYear == "":
                            print()
                            print("   Data entry error - Vechile Year cannot be blank.")
                            print()
                        elif set(VehicleYear).issubset(Allowed_Char_Num) == False:
                            print()
                            print("   Data entry error - Vehicle Year contains invalid characters.")
                            print()
                        else:
                            break

                    while True:
                    
                        Allowed_Char = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz-'")

                        while True:
                                VehicleModel = input("Enter the Vehicle Model (Ford): ").title()
                                if VehicleYear == "":
                                        print()
                                        print("   Data entry error - Model cannot be blank.")
                                        print()
                                elif set(CustLastName).issubset(Allowed_Char) == False:
                                        print()
                                        print("   Data entry error - Vehicle model contains invalid characters.")
                                        print()
                                else:
                                        break
                                
                        while True:
                                    VehicleMake = input("Enter the Vehicle Make (F150): ").title()
                                    if VehicleMake == "":
                                            print()
                                            print("   Data entry error - Vehicle Make cannot be blank.")
                                            print()
                                    else:
                                            break
                                    

                        #Selling and Trade price Input
                        while True:
                                    
                                    try:
                                            SellingPrice = input(f"Enter the Selling Price: ")
                                            SellingPrice = float(SellingPrice)
                                    except:
                                            print()
                                            print("   Data entry error - Vehcile price contains invalid characters.")
                                            print()
                                    else:
                                            if SellingPrice > 50000:
                                                print()
                                                print("   Data entry error - Vehcile price must be below $50,000.")
                                                print()
                                            else:
                                                break   


                        while True:

                            Allowed_Char_Num = set("1234567890.")

                            while True:
                                    TradeVal = input(f"Enter the Trade Value: ")
                                    TradeVal = float(TradeVal)
                                    if TradeVal == "":
                                        print()
                                        print("   Data entry error - Model cannot be blank.")
                                        print()
                                    elif set(str(TradeVal)).issubset(Allowed_Char_Num) == False:
                                            print()
                                            print("   Data entry error - Trade allowance contains invalid characters.")
                                            print()
                                    if TradeVal > SellingPrice:
                                        print()
                                        print("   Data entry error -  Trade value cannot exceed Selling Price")
                                        print()
                                    else:
                                        break

                        #Salesperson Info Input
                            while True:     
                                    SalePerson = input(f"Enter the Name of Sales person: ").title()
                                    if SalePerson  == "":
                                        print()
                                        print('    Data entry error - Customer name cannot be blank.') 
                                        print()
                                    elif set(CustLastName).issubset(Allowed_Char) == False: 
                                        print()
                                        print("     Data entry error - Customer Name contains invalid characters.")
                                        print()
                                    else:
                                        break

                                    print()

                        # Invoice Info Section
                            InvoiceDate = datetime.date.today()
                            print(f"{InvoiceDate}")

                            CustNameInv = f"{CustFirstName[0].upper()}{CustLastName.title()}"

                            CustPhoneNumInv = f"{CustPhoneNum[6:10]}"

                            VehcileInfo = f"{VehicleYear}\n{VehicleModel.title()}\n{VehicleMake.title()}"
                            

                        #Receipt ID section XX-XXX-XXXX
                            CustNameID = [CustFirstName[0].upper(),CustLastName[0].upper()]

                            LicensePlateID = f"{PlateNum[3:6]}"

                            PhoneNumID = f"{CustPhoneNum[6:10]}"

                            ReceiptID = f"{CustNameID[0]}{CustNameID[1]}-{LicensePlateID}-{PhoneNumID}"

                            
                        #calculations section 
                            PriceAfterTrade = SellingPrice - TradeVal

                            if SellingPrice <= 15000:
                                LicenseCost = SellingPrice + LICENSE_FEE_LOWER
                            else:
                                    LicenseCost = SellingPrice + LICENSE_FEE_HIGHER

                            LuxFee = TRANSFER_FEE + HIGH_TRANSFER_FEE

                            if SellingPrice <= 20000:
                                    TransferCost = TRANSFER_FEE / 100 * SellingPrice
                            else:
                                    TransferCost = LuxFee / 100 * SellingPrice

                            Subtotal = PriceAfterTrade + LicenseCost + TransferCost 

                            HST = HST_FEE / 100 * Subtotal

                            TotalSalePrice = Subtotal + HST

                            FinFee = FINANCING_FEE * LOAN_YEARS

                            TotalPaymentCost = TotalSalePrice + FinFee

                            NumMonPayment = LOAN_YEARS * 12

                            TotalMonPayment = TotalSalePrice / NumMonPayment


                            TotalMonPaymentDsp = "${:,.2f}".format(TotalMonPayment)
                      

                            try: 
                                CurDate = datetime.date.today()
                                FirstPaymentDate = (CurDate.replace(day=1) + datetime.timedelta(days=32)).replace(day=CurDate.day)

                            except ValueError:  
                                FirstPaymentDate =CurDate.replace(day=1) + datetime.timedelta(days=32).replace(day=1)
                                LastDayOfMon = (FirstPaymentDate.replace(day=1) + datetime.timedelta(days=32)).replace(day=1) - datetime.timedelta(days=1)
                                FirstPaymentDate = FirstPaymentDate.replace(day=LastDayOfMon.day)

                            CurPaymentDate = FirstPaymentDate
                            RemBal = TotalMonPayment

                            Year = CurPaymentDate.year
                            Month = CurPaymentDate.month + 1
                                
                            if Month > 12:
                                        Month = 1
                                        Year += 1

                            day = min(CurPaymentDate.day, datetime.date(Year, Month, 1).replace(day=28).day + 3)

                            try:
                                    CurPaymentDate = CurPaymentDate.replace(year=Year, month=Month)

                            except ValueError: 
                                    CurPaymentDate = datetime.date(Year, Month, 1) + datetime.timedelta(days=-1) # Last day of previous month
                                    CurPaymentDate = CurPaymentDate.replace(day=min)(CurPaymentDate.day, datetime.date(Year, Month, 1).day)
                                                                      
                            
                            print()
                            print(f"Honest Harry Car Sales                          Invoice Date:   {InvoiceDate}")
                            print(f"Used Car Sale and Receipt                       Receipt No:     {ReceiptID}")
                            print()
                            SellingPriceDsp = "${:,.2f}".format(SellingPrice)
                            print(f"                                         Sales Price:            {SellingPriceDsp:>10}")
                            TradeValDsp = "${:,.2f}".format(TradeVal)
                            print(f"Sold to:                                 Trade Allowance:        {TradeValDsp:>10}")
                            print(f"                                         ----------------------------------")
                            PriceAfterTradeDsp = "${:,.2f}".format(PriceAfterTrade)
                            print(f"      {CustNameInv}                      Price after Trade:      {PriceAfterTradeDsp:>10}")
                            LicenseCostDsp = "${:,.2f}".format(LicenseCost)
                            print(f"      {CustPhoneNum}                     License Fee:            {LicenseCostDsp:>10}")
                            TransferCostDsp = "${:,.2f}".format(TransferCost)
                            print(f"                                         Transfer Fee:           {TransferCostDsp:>10}")
                            print(f"                                         ----------------------------------")
                            SubtotalDsp = "${:,.2f}".format(Subtotal)
                            print(f"Car Details:                             Subtotal:               {SubtotalDsp:>10}")
                            HSTDsp = "${:,.2f}".format(HST)
                            print(f"                                         HST:                    {HSTDsp:>10}")
                            print(f"    {VehcileInfo}                                 -----------------------------------")
                            TotalSalePriceDsp = "${:,.2f}".format(TotalSalePrice)
                            print(f"                                         Total Sales Price:      {TotalSalePriceDsp:>10}")
                            print()
                            print(F"----------------------------------------------------------------------------")
                            print()
                            print(f"                            Financing     Total        Monthly")
                            print(f"   # Years    # Payments       Fee        Price        Payment")
                            print(f"   -----------------------------------------------------------")
                            print(f"       1          12         {FinFee}     {TotalSalePriceDsp}       {TotalMonPaymentDsp}")
                            print(f"       2          24         {FinFee}     {TotalSalePriceDsp}       {TotalMonPaymentDsp}")
                            print(f"       3          36         {FinFee}     {TotalSalePriceDsp}       {TotalMonPaymentDsp}")
                            print(f"       4          48         {FinFee}     {TotalSalePriceDsp}       {TotalMonPaymentDsp}")
                            print(f"   -----------------------------------------------------------")
                            print(f"  First payment date: {FirstPaymentDate}")
                            print(F"----------------------------------------------------------------------------")
                            print(f"                  Best used cars at the best prices!")
                            break
                        break
                    break
       



