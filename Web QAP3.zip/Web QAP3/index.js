// Desc: Mo's Lawncare Services Invoice
// Author: Samantha Stroud
// Dates: July 17, 2025


var $ = function (id) {
  return document.getElementById(id);
};


// Define format options for printing.
const cur2Format = new Intl.NumberFormat("en-CA", {
  style: "currency",
  currency: "CAD",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const per2Format = new Intl.NumberFormat("en-CA", {
  style: "percent",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const per0Format = new Intl.NumberFormat("en-CA", {
  style: "percent",
  minimumFractionDigits: "0",
  maximumFractionDigits: "0",
});

const com2Format = new Intl.NumberFormat("en-CA", {
  style: "decimal",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

// Start main program here

// Define program constants.
const BORDER_SQFT = 0.04; // 4% of total square footage
const BORDER_COST_RATE = 0.35; // $0.35 per square foot 
const LAWN_MOWING_SQFT = .95; // 95% of square footage 
const MOWING_COST_RATE = 0.07; // 0.07 per square foot 
const HST_RATE = 0.15; // 15% tax
const FERT_TREAT_RATE = 0.05 // .05 per square foot 
const ENVIOR_RATE = 0.014 // 1.4% Enviorment Fee

// Gather user inputs.
let CustName = prompt("Enter Customers Name: ")
let CustAdd = prompt("Enter the Customers address: ")
let City = prompt("Enter the City: ")
let PhoneNum = prompt("Enter the Customers Phone Number ###-###-####: ")
let NumOfSquFt = prompt("Enter the amount of square feet (#####): ")
NumOfSquFt = parseFloat(NumOfSquFt)

// Calcuations Section 

let BorderArea = NumOfSquFt * BORDER_SQFT
let BorderCost = BorderArea * BORDER_COST_RATE

let LawnArea = NumOfSquFt * LAWN_MOWING_SQFT
let LawnCost =  LawnArea * MOWING_COST_RATE

let FertCost = NumOfSquFt * FERT_TREAT_RATE

let TotalCharges = BorderCost + LawnCost + FertCost


let SaleTax = TotalCharges * HST_RATE
let EnviormentTax = TotalCharges * ENVIOR_RATE

let InvoiceTotal =  TotalCharges + SaleTax + EnviormentTax

//Display Results 

// Customer Results 
document.getElementById('cust-name').textContent = CustName
document.getElementById('cust-address').textContent = CustAdd
document.getElementById('cust-city').textContent = City
document.getElementById('cust-phone').textContent = PhoneNum

// Property 
document.getElementById('prop-size').textContent = NumOfSquFt.toLocaleString() + 'sq ft';

// Cost
document.getElementById('bord-cost').textContent = BorderCost.toLocaleString('en-CA', { style: 'currency', currency: 'CAD' });
document.getElementById('mowing-cost').textContent = LawnCost.toLocaleString('en-CA', { style: 'currency', currency: 'CAD' });
document.getElementById('fert-cost').textContent = FertCost.toLocaleString('en-CA', { style: 'currency', currency: 'CAD' });

document.getElementById('total-charge').textContent = TotalCharges.toLocaleString('en-CA', { style: 'currency', currency: 'CAD' });

document.getElementById('sale-tax').textContent = SaleTax.toLocaleString('en-CA', { style: 'currency', currency: 'CAD' });
document.getElementById('envior-cost').textContent = EnviormentTax.toLocaleString('en-CA', { style: 'currency', currency: 'CAD' });

document.getElementById('invoice-cost').textContent = InvoiceTotal.toLocaleString('en-CA', { style: 'currency', currency: 'CAD' });



